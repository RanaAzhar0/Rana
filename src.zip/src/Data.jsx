import Img1 from "./images/new folder02.png"



const navbarData={
    logo:[Img1],
    liF:["SHOP","GIFTS"],
    liL:["Blog","Wineful Stoy","Contacts"]
}




export {navbarData}